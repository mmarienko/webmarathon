<?php

interface ControllerInterface
{
    public function __construct();

    public function execute();
}
